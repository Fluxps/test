package com.rspsi.plugins;

import com.rspsi.MainWindow;

public interface ApplicationPlugin {
	
	void initialize(MainWindow window);

}
