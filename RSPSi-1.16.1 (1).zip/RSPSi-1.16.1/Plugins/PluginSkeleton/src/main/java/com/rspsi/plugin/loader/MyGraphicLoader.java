package com.rspsi.plugin.loader;

import org.displee.cache.index.archive.Archive;

import com.jagex.cache.anim.Graphic;
import com.jagex.cache.loader.anim.GraphicLoader;


public class MyGraphicLoader extends GraphicLoader {

	@Override
	public int count() {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public Graphic forId(int arg0) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void init(Archive arg0) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void init(byte[] arg0) {
		// TODO Auto-generated method stub
		
	}

}
