package com.rspsi.plugin.loader;


import com.jagex.cache.anim.Frame;
import com.jagex.cache.loader.anim.FrameLoader;

public class MyFrameLoader extends FrameLoader {

	@Override
	protected Frame forId(int arg0) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void load(int arg0, byte[] arg1) {
		// TODO Auto-generated method stub
		
	}


}
