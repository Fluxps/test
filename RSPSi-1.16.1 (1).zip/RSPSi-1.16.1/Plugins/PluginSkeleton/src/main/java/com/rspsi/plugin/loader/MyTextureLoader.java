package com.rspsi.plugin.loader;

import org.displee.cache.index.archive.Archive;

import com.jagex.cache.loader.textures.TextureLoader;
import com.jagex.draw.textures.Texture;


public class MyTextureLoader extends TextureLoader {

	@Override
	public Texture forId(int arg0) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public int[] getPixels(int arg0) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void init(Archive arg0) {
		// TODO Auto-generated method stub

	}

	@Override
	public boolean isTransparent(int arg0) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public void setBrightness(double arg0) {
		// TODO Auto-generated method stub

	}

	@Override
	public int count() {
		// TODO Auto-generated method stub
		return 0;
	}


}
