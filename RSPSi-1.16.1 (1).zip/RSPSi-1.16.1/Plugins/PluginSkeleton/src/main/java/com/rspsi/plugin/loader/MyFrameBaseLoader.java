package com.rspsi.plugin.loader;

import com.jagex.cache.anim.FrameBase;
import com.jagex.cache.loader.anim.FrameBaseLoader;
import com.jagex.io.Buffer;

public class MyFrameBaseLoader extends FrameBaseLoader {

	@Override
	public FrameBase decode(Buffer buffer) {
		return null;
	}

}
