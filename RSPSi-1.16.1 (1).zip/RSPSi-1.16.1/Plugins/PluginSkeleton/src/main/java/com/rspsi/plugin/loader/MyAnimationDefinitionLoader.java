package com.rspsi.plugin.loader;

import org.displee.cache.index.archive.Archive;

import com.jagex.cache.anim.Animation;
import com.jagex.cache.loader.anim.AnimationDefinitionLoader;


public class MyAnimationDefinitionLoader extends AnimationDefinitionLoader {


	@Override
	public void init(Archive archive) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public int count() {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public Animation forId(int id) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void init(byte[] arg0) {
		// TODO Auto-generated method stub
		
	}


}
