package com.rspsi.plugin.loader;

import org.displee.cache.index.archive.Archive;

import com.jagex.cache.def.Floor;
import com.jagex.cache.loader.floor.FloorDefinitionLoader;
import com.jagex.cache.loader.floor.FloorType;


public class MyFloorDefinitionLoader extends FloorDefinitionLoader {



	@Override
	public Floor getFloor(int arg0, FloorType arg1) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public int getSize(FloorType arg0) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public void init(Archive arg0) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void init(byte[] arg0) {
		// TODO Auto-generated method stub
		
	}
	
	

}
