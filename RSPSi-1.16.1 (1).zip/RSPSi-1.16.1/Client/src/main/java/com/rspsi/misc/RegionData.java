package com.rspsi.misc;

import lombok.Data;

@Data
public class RegionData {
	
	private final int hash, loc, obj;

}
