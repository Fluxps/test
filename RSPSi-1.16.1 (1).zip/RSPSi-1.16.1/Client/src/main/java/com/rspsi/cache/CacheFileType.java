package com.rspsi.cache;

public enum CacheFileType {

	CONFIG, MODEL, ANIMATION, SOUND, MAP, TEXTURE, SKELETON, SPRITE, VARBIT, LOC, SPOT
}
