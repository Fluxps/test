package com.rspsi.misc;

import com.google.common.collect.Maps;
import javafx.scene.Node;

import java.util.Map;

public class KeyConfiguration {

	private Map<KeyConfiguration, Node> keyConfigurationNodeMap = Maps.newConcurrentMap();

	public static void load(){

	}


}
