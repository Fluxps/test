package com.rspsi.misc;

public class FixedIntegerKeyMap<V> extends FixedHashMap<Integer, V>{

	public FixedIntegerKeyMap(int size) {
		super(size);
	}


}
