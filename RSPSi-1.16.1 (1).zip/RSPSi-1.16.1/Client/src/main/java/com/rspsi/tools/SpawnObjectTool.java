package com.rspsi.tools;

import com.rspsi.misc.Location;

public class SpawnObjectTool extends Tool {
	

	@Override
	public void onMouseMove() {
		// TODO Auto-generated method stub

	}

	@Override
	public void onMouseClick() {
		// TODO Auto-generated method stub

	}

	@Override
	public String name() {
		// TODO Auto-generated method stub
		return "spawn_object";
	}

}
