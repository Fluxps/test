package com.rspsi.misc;

public class FixedLongKeyMap<V> extends FixedHashMap<Long, V>{

	public FixedLongKeyMap(int size) {
		super(size);
	}


}
