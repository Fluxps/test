package com.rspsi.misc;

public class StatusUpdate {
	
	private String text;
	
	public StatusUpdate(String text) {
		this.text = text;
	}
	
	public String getText() {
		return text;
	}

}
