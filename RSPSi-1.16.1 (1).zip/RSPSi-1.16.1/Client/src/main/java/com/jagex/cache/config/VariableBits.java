package com.jagex.cache.config;

public class VariableBits {

	private int high;
	private int low;
	private int setting;
	
	public void setHigh(int high) {
		this.high = high;
	}

	public void setLow(int low) {
		this.low = low;
	}

	public void setSetting(int setting) {
		this.setting = setting;
	}

	public int getHigh() {
		return high;
	}

	public int getLow() {
		return low;
	}

	public int getSetting() {
		return setting;
	}

}