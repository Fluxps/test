package com.jagex.map.object;

public enum WorldObjectType {
	GAME_OBJECT, GROUND_DECORATION, LINKABLE_WORLD_OBJECT, WALL, WALL_DECORATION
}
