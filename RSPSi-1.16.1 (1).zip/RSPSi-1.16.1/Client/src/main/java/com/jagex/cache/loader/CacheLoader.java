package com.jagex.cache.loader;

public class CacheLoader {

}
