package com.jagex.cache.loader.floor;

public enum FloorType {
	OVERLAY, UNDERLAY
}
