package com.jagex.util;

import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
public class MapObjectData {
	
	private int id, x, y, z, type, orientation;

}
