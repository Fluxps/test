package com.jagex.cache.loader.sprite;

public enum MinimapSpriteType {
	SCENE, FUNCTION
}
