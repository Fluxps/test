package com.jagex.cache.config;

public class VariableParameter {

	private int parameter;

	public int getParameter() {
		return parameter;
	}

	public void setParameter(int parameter) {
		this.parameter = parameter;
	}
	
}