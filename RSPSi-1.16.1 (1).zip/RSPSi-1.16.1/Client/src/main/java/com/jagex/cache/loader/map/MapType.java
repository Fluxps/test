package com.jagex.cache.loader.map;

public enum MapType {
	LANDSCAPE, OBJECT
}
