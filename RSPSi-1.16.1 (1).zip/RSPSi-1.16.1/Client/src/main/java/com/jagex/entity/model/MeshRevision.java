package com.jagex.entity.model;

public enum MeshRevision {
	REVISION_317, REVISION_525, REVISION_622
}
