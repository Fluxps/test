package org.major.map;

public class TileAttributes {

	public static int RENDER_TILE_NORTH = 8;
	public static int RENDER_TILE_SOUTH = 2;
	public static int RENDER_TILE_WEST = 1;
	public static int RENDER_TILE_EAST = 4;

}
